package com.example.exaula3;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        Button ok = findViewById(R.id.button);
        EditText nome = findViewById(R.id.EditNome);
        EditText senha = findViewById(R.id.EditSenha);


        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nomeTexto = nome.getText().toString();
                String senhaTexto = senha.getText().toString();

                if (nomeTexto.equals("admin") && senhaTexto.equals("admin")) {
                    Toast.makeText(MainActivity.this, "Login efetuado com sucesso", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(MainActivity.this, "Usuário ou senha incorretos", Toast.LENGTH_LONG).show();

                }
            }
        });
    }
}