package com.example.persistenciacomroomdatabase;

import androidx.room.Database;
import androidx.room.RoomDatabase;
@Database(entities = {Usuario.class}, version = 1)
public abstract class MyDataBase extends RoomDatabase {
    public abstract UsuarioDAO usuarioDAO();
}
