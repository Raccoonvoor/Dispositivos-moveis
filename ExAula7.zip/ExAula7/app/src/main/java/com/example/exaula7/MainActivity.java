package com.example.exaula7;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

        private EditText usuario;

        private EditText senha;

        private Button login;


        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            EdgeToEdge.enable(this);
            setContentView(R.layout.activity_main);

            inicializaTelaLogin();
        }
        private void inicializaTelaLogin() {
            usuario = findViewById(R.id.mainActivity_editTextUsuario);
            senha = findViewById(R.id.mainActivity_editTextTextSenha);
            login = findViewById(R.id.mainActivity_buttonLogin);

            login.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    boolean loginCorreto = validaLogin();
                    if (loginCorreto) { // é a mesma coisa de if(loginCorreto == true){
                        Intent segundaTela = new Intent(MainActivity.this, TelaCadastro.class);
                        startActivity(segundaTela);
                    } else {
                        Toast.makeText(MainActivity.this, "Login ou senha incorretos", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
            private boolean validaLogin () {
                String usuarioInformado = usuario.getText().toString();
                String senhaInformada = senha.getText().toString();
                if (usuarioInformado.equals("professor") && senhaInformada.equals("12345")) {
                    return true;
                } else {
                    return false;
                }
            }

        }