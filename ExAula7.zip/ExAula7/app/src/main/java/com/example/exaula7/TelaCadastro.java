package com.example.exaula7;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class TelaCadastro extends AppCompatActivity {

    private EditText nome;

    private EditText matricula;

    private EditText nota1;

    private EditText nota2;

    private Button verificar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_tela_cadastro);
        
        inicializaTelaCadastro();
    }

    private void inicializaTelaCadastro() {
        nome = findViewById(R.id.TelaCadastro_editTextTextNome);
        matricula = findViewById(R.id.TelaCadastro_editTextTextMatricula);
        nota1 = findViewById(R.id.TelaCadastro_editTextTextNota1);
        nota2 = findViewById(R.id.TelaCadastro_editTextTextNota2);

        verificar = findViewById(R.id.TelaCadastro_buttonVerificar);

        verificar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chamaTelaResultado();
            }
        });
    }

    private void chamaTelaResultado() {
        Intent telaResultado = new Intent(this, TelaResultado.class);
        telaResultado.putExtra("chaveNome", nome.getText().toString());
        telaResultado.putExtra("chaveMatricula", matricula.getText().toString());
        telaResultado.putExtra("chaveNota1", nota1.getText().toString());
        telaResultado.putExtra("chaveNota2", nota2.getText().toString());

        startActivity(telaResultado);
    }
}