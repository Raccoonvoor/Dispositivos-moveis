package com.example.correcaoprovaradiobutton;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    // Declaração de variáveis de CLasse
    private RadioGroup pergunta1;

    private RadioGroup pergunta2;

    private ImageButton enviar;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        inicializaTela();
    }

    // A partir daqui eu começo
    private void inicializaTela() {
        pergunta1 = findViewById(R.id.radioGroupPergunta1);
        pergunta2 = findViewById(R.id.radioGroupPergunta2);
        enviar = findViewById(R.id.imageButtonEnviar);

        enviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chamaTelaResultado();
            }
        });

    }

    private void chamaTelaResultado() {

    //Capturando o valor selecionado no RadioGrouo pergunta1

        int idResposta1 = pergunta1.getCheckedRadioButtonId();
        //Criando um novo RadioBUtton, com o id do RadioButton selecionado na pergunta1

        RadioButton resposta1 = findViewById(idResposta1);
        //Jogando esse valor selecionado em uma String

        String resposta1Selecionada = resposta1.getText().toString();
        //Fazendo a mesma coisa, pra pergunta2

        int idResposta2 = pergunta2.getCheckedRadioButtonId();
        RadioButton resposta2 = findViewById(idResposta2);
        String resposta2Selecionada = resposta2.getText().toString();

        Intent segundaTela = new Intent(MainActivity.this, TelaResultado.class);
        segundaTela.putExtra("chaveResposta1", resposta1Selecionada);
        segundaTela.putExtra("chaveResposta2", resposta2Selecionada);
        startActivity(segundaTela);
    }
}