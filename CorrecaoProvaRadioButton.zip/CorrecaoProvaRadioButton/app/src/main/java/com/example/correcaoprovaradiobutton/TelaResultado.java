package com.example.correcaoprovaradiobutton;

import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class TelaResultado extends AppCompatActivity {
    private TextView resultado;
    private Imageview imagemResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_tela_resultado);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        inicializaTelaResultado();
    }

    private void inicializaTelaResultado() {
        resultado = findViewById(R.id.textViewResultado);
        String resposta1 = getIntent().getStringExtra("chaveResposta1");
        String resposta2 = getIntent().getStringExtra("chaveResposta2");

        int qtdAcertos = calculaNotaFinal(resposta1, resposta2);

        if(qtdAcertos == 2) {
            resultado.setText("Sua nota foi 10");
        } else if(qtdAcertos == 1){
            resultado.setText("Sua nota foi 5");
        }else {
            resultado.setText("Sua nota foi 0");
        }
}

    private int calculaNotaFinal(String resposta1, String resposta2) {
        int qtdAcertos = 0;
        if(resposta1.equals("Verdadeiro")){
            qtdAcertos++;
        }
        if(resposta2.equals("Verdadeiro")){
            qtdAcertos++;
        }
        return qtdAcertos;
    }
}
