package com.example.revisaoprova22;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;
@Dao
public interface GastoDao {
    @Insert
    void inserir(Gasto gastoAtual);
    @Query("SELECT * FROM gastos")
    List<Gasto> buscaTodosGastos();
    @Query("SELECT * FROM gastos ORDER BY valor DESC LIMIT 1")
    Gasto buscaMaiorGasto();

    @Query("SELECT * FROM gastos ORDER BY id DESC LIMIT 1")
    Gasto buscaUltimoGasto();

    @Delete
    void deleteGasto(Gasto gasto);
}
