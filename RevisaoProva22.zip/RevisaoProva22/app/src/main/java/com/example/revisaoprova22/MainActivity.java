package com.example.revisaoprova22;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.room.Room;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    private EditText descricao, valor;
    private TextView informacoes;
    private Button cadastrar;
    private AppDatabase db;
    private float valorTotal;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        descricao = findViewById(R.id.editTextTextDescricao);
        valor = findViewById(R.id.editTextValor);
        informacoes = findViewById(R.id.textViewInformacoes);
        cadastrar = findViewById(R.id.buttonCadastrar);

        db = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "meu_banco.db").build();

        cadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                salvarGasto();
            }
        });
    }

    private void salvarGasto() {
        String descricaoInformada = descricao.getText().toString();
        float valorInformado = Float.parseFloat(valor.getText().toString());

        Gasto gasto = new Gasto(0, valorInformado, descricaoInformada);

        new Thread(new Runnable() {
            @Override
            public void run() {
                db.gastoDao().inserir(gasto); // Aqui pode
                List<Gasto> lista = db.gastoDao().buscaTodosGastos();
                valorTotal = 0;
                for (Gasto gastoAtual: lista) {
                    valorTotal += gastoAtual.getValor();

                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        informacoes.setText("Você gastou até o momento:"+ valorTotal);
                        descricao.setText("");
                        valor.setText("");
                        Toast.makeText(MainActivity.this, "Seu gasto foi cadastrado!", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        }).start();
        //db.gastoDao().inserir(gasto); // Aqui não pode


    }
}