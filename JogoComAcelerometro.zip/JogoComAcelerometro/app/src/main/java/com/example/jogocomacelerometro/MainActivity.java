package com.example.jogocomacelerometro;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private Sensor acelerometro;
    private SensorManager gerenciador;
    private SensorEventListener listener;
    private ImageView aviao;
    private FrameLayout layoutTiro;
    private Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        startGame();
    }


    @Override
    protected void onResume() {
        super.onResume();
        gerenciador.registerListener(listener,acelerometro, SensorManager.SENSOR_DELAY_GAME);
    }

    @Override
    protected void onPause() {
        super.onPause();
        gerenciador.unregisterListener(listener);
    }

    private void startGame() {
        aviao = findViewById(R.id.imageViewAviao);
        layoutTiro = findViewById(R.id.layout_tiro);
        gerenciador = (SensorManager) getSystemService(SENSOR_SERVICE);
        acelerometro = gerenciador.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        moveAviao();

        handler.post(new Runnable() {
            @Override
            public void run() {
                disparaTiro();
                handler.postDelayed(this, 100);
            }
        });
    }

    private void disparaTiro() {
        ImageView tiro = new ImageView(this);
        tiro.setImageResource(R.drawable.tiro);
        tiro.setLayoutParams(new FrameLayout.LayoutParams(80,80));
        tiro.setX(aviao.getX() + 140);
        tiro.setY(aviao.getY() - 80);

        ObjectAnimator animacao = ObjectAnimator.ofFloat(tiro, "y", 0);
        animacao.setInterpolator(new LinearInterpolator());
        animacao.setDuration(2000);
        animacao.start();

        layoutTiro.addView(tiro);

        animacao.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                layoutTiro.removeView(tiro);
            }
        });
    }

    private void moveAviao() {
        listener = new SensorEventListener() {
            @Override
            public void onSensorChanged(SensorEvent event) {
                float eixoX = event.values[0];
                float novaPosicao = aviao.getX() - eixoX;
                float bordaEsquerda = 0;
                float bordaDireita = getResources().getDisplayMetrics().widthPixels;

                if(novaPosicao < bordaEsquerda){
                    novaPosicao = bordaEsquerda;

                }

                if(novaPosicao > bordaDireita - aviao.getWidth()){
                    novaPosicao = bordaDireita - aviao.getWidth();
                }

                aviao.setX(novaPosicao);

            }

            @Override
            public void onAccuracyChanged(Sensor sensor, int accuracy) {

            }
        };
    }
}