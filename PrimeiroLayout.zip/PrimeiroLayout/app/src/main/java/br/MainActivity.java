package br;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.Nullable;

import br.com.example.myapplication.R;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //setando na MainActivity o layout criado em res/layout/. Notem que a classe R te permite navegar dentro do diretório "res"
        setContentView(R.layout.activity_main);

        //vinculando o elemento TextView, criado no layout "activity_main", a um objeto do tipo TextView. Notem que a classe "R" te permite encontrar o elemento a partir do id definido (neste caso, o id é textView2)
        TextView textView = findViewById(R.id.textView2);

        textView.setText("Olá mundo");
    }
}
