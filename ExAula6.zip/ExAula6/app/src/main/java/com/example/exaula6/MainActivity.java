package com.example.exaula6;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText nome;

    private EditText matricula;

    private EditText nota1;

    private EditText nota2;

    private Button botaoCalcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        inicializaPrimeiraTela();
    }

    public void inicializaPrimeiraTela(){
        nome = findViewById(R.id.editTextNome);
        matricula = findViewById(R.id.editTextMatricula);
        nota1 = findViewById(R.id.editTextNota1);
        nota2 = findViewById(R.id.editTextNota2);
        botaoCalcular = findViewById(R.id.buttonCalcular);

        botaoCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chamadaSegundaTela();
            }
        });
    }

    private void chamadaSegundaTela() {
        String nomeInformado = nome.getText().toString();
        String matriculaInformada = matricula.getText().toString();
        String nota1Informada = nota1.getText().toString();
        String nota2Informada = nota2.getText().toString();

        Intent passaSegundaTela = new Intent(this, TelaResultado.class);
        passaSegundaTela.putExtra("nome", nomeInformado);
        passaSegundaTela.putExtra("matriculaInformada", matriculaInformada);
        passaSegundaTela.putExtra("minhaNota1", nota1Informada);
        passaSegundaTela.putExtra("minhaNota2", nota2Informada);
        startActivity(passaSegundaTela);
    }
}