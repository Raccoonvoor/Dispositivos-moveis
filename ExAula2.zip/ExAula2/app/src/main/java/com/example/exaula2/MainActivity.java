package com.example.exaula2;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);


        TextView titulo = findViewById(R.id.titulo);
        Button botaoTraduzir = findViewById(R.id.button_traduzir);

        titulo.setText("Hello World");

        botaoTraduzir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                titulo.setText("Olá mundo");
            }
        });
    }
}
